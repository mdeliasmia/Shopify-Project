var GAReviews = GAReviews || {};

GAReviews.clientId = 'c2hvcGl0b2ZmY28=';
GAReviews.clientAssetId = '35737f01e709eec31a12b1e40abc01d9';

GAReviews.appUrl = 'https://app.shopifydevelopers.net/aliexpress-reviews/';
GAReviews.init = function($){
    window.spuritJQ = $;

    $(document).ready(function(){

        var installed = false;
        $("script").each(function() {
             if ($(this).text().indexOf("globoreviews_init.js?") != -1 && $(this).text().indexOf("asyncLoad") != -1 && $(this).text().indexOf("initSchema") == -1) {
                 installed = true;
             }
         });
        if(installed){
            if( $('.globo-reviews-badge').length > 0 ){
                var product_ids = [];
                $('.globo-reviews-badge').each(function(){
                    product_ids.push( $(this).attr('data-product-id') );
                });

                $.ajax({
                    type:    "POST",
                    url:     GAReviews.appUrl+'badge/'+GAReviews.clientId,
                    data:    { ids: product_ids },
                    dataType: 'jsonp',
                    success: function(response){
                        if(response.success){
                            $.each(response.data, function(product_id, review){
                                var stars_str = '';
                                for(i = 1; i <= 5; i++){
                                    if(i <= review.avg){
                                        stars_str += '<i class="gar-icon gar-icon-star" aria-hidden="true"></i>';
                                    }else if(i > review.avg && i < review.avg + 1 ){
                                        stars_str += '<i class="gar-icon gar-icon-star-half-alt" aria-hidden="true"></i>';
                                    }else{
                                        stars_str += '<i class="gar-icon gar-icon-star-empty" aria-hidden="true"></i>';
                                    }
                                }
                                $('.globo-reviews-badge[data-product-id="'+product_id+'"]').html(stars_str);
                            });
                        }
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        jsonValue = jQuery.parseJSON( jqXHR.responseText );
                        console.log(jsonValue.description);
                    }
                });
            }

            window.addEventListener ? addEventListener("message", listener, false) : attachEvent("onmessage", listener);

            var injectReviews = function() {
            	var reviews = document.getElementById('globo-reviews');
            	if (!reviews) return;

            	if (reviews.getAttribute('data-upgraded')) return;
            	reviews.setAttribute('data-upgraded', 'true');

            	GAReviews.productId = reviews.getAttribute('data-product-id');
            	if (GAReviews.productId == "{{product.id}}")
            		return console.error("GAReviews - product id is set to \"{{ product.id }}\" which is not a real product Id, the widget cannot be injected using settings or be placed inside a {% raw %} directive");

            	var url = GAReviews.appUrl+'reviews/'+GAReviews.clientId;
            	var qs = [];

            	var aggregate = reviews.getAttribute('data-gar-aggregate') != null;
            	if (aggregate && GAReviews.productId)
            		qs.push("productId=" + GAReviews.productId);
            	else if (GAReviews.productId)
            		url += '/' + GAReviews.productId;

            	var mode = reviews.getAttribute('data-mode');
            	if (mode)
            		qs.push("mode=" + mode);

            	var productIds = reviews.getAttribute('data-or-productIds');
            	if (productIds)
            		qs.push("productIds=" + productIds);

            	var limit = reviews.getAttribute('data-limit');
            	if (limit)
            		qs.push("limit=" + limit);

            	var paging = reviews.getAttribute('data-paging');
            	if (paging)
            		qs.push("paging=" + paging);

            	var header = reviews.getAttribute('data-header');
            	if (header)
            		qs.push("header=" + header);

            	var thumbnails = reviews.getAttribute('data-product-thumbnails');
            	if (thumbnails)
            		qs.push("thumbnails=" + thumbnails);

            	if (qs.length > 0)
            		url += "?" + qs.join('&');

            	var h = '85px';
            	var w = '100%';
            	reviews.innerHTML = '<iframe id="' + 'GAReviewsFrame' + '" src="' + url + '" height="' + h + '" width="' + w + '" frameborder="0" scrolling="no" margin="0" style="overflow:hidden;height:' + h + ';width:' + w + ';"></iframe>';
            };
            injectReviews();
            setInterval(injectReviews, 1000);
        }
    });

    $(document).mouseup(function(e)
    {
        var container = $("#globoPopupOverlay iframe");
        if (!container.is(e.target) && container.has(e.target).length === 0)
        {
            document.body.style.overflow = '';
    		document.body.style.position = '';
    		var self = document.getElementById('globoPopupOverlay');
    		if (self) self.parentNode.removeChild(self);
        }
    });

    function iframe(id, url, h, w) {
		return '<iframe id="' + id + '" src="' + url + '" height="' + h + '" width="' + w + '" frameborder="0" scrolling="no" margin="0" style="overflow:hidden;height:' + h + ';width:' + w + ';"></iframe>';
	}

	function inject(url, id, h, options) {
		options = options || {};
		var body = document.body;
		var div = document.createElement('div');

		div.id = 'globoPopupOverlay';
		div.style.cssText = "width: 100%;height:100%; position:fixed; font-family: Arial, Helvetica, sans-serif;top: 0;right: 0;bottom: 0;left: 0;z-index: 9999999999;opacity: 1;-webkit-transition: opacity 400ms ease-in;-moz-transition: opacity 400ms ease-in;transition: opacity 400ms ease-in;overflow:auto;-webkit-overflow-scrolling: touch;";
		if (options && options.overlay)
			div.style.cssText += "background: rgba(49, 49, 49, 0.9);";
			div.innerHTML = '<div style="position: relative;width: 90%;margin: 5% auto;' + (options.width ? ("max-width:" + options.width) : "max-width:1170px") + ';">' + iframe(id, url, h, '100%') + '</div>';
		body.appendChild(div);

		body.style.overflow = 'hidden';

		var iOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
		if (iOS)
			body.style.position = 'fixed';

		body.style.width = '100%';
	}

    function listener(event) {

		if (event.origin != "https://app.shopifydevelopers.net")
			return;

        var m = typeof(event.data) == "string" ? JSON.parse(event.data) : event.data;
        if (m.type == 'resize') {
			var frame = document.getElementById(m.frame);
			frame.height = m.height + 'px';
			frame.style.height = m.height + 'px';
		}

        if (m.type == 'write') {
			(function() {
				var productId = m.productId || GAReviews.productId;
				if (!productId) return console.error('Cannot open write dialog, productId is not defined');

				var url = GAReviews.appUrl + 'write/' + GAReviews.clientId + '/' + GAReviews.productId;

				inject(url, 'globoPopupDialog', '500px', { overlay: true, width: '800px' });
			})();
		}

		if (m.type == 'closeModal') {
			document.body.style.overflow = '';
    		document.body.style.position = '';
    		var self = document.getElementById('globoPopupOverlay');
    		if (self) self.parentNode.removeChild(self);
		}

		if (m.type == 'reviewDetails') {
			var url = GAReviews.appUrl+'review/' + GAReviews.clientId + '/' + m.postId;
			inject(url, 'reviewDetails', '500px', { width : "1170px", overlay: true });
		}
    };


},

GAReviews.loadScript = function(url, callback, errcallback){
    var script = document.createElement("script");
    script.type = "text/javascript";
    if (script.readyState){
        script.onreadystatechange = function(){
            if (script.readyState == "loaded" || script.readyState == "complete"){
                script.onreadystatechange = null;
                callback();
            }
        };
        setTimeout(function(){
            if(script.onreadystatechange !== null){
                if(errcallback !== undefined) errcallback();
            }
        },3000);
    } else {
        script.onload = function(){
            callback();
        };
        script.onerror = function(){
            if(errcallback !== undefined) errcallback();
        }
    }
    script.src = url;
    document.getElementsByTagName("head")[0].appendChild(script);
},

GAReviews.getParams = function(script_name) {
  var scripts = document.getElementsByTagName("script");
  for(var i=0; i<scripts.length; i++) {
    if(scripts[i].src.indexOf("/" + script_name) > -1) {
      var pa = scripts[i].src.split("?").pop().split("&");
      var p = {};
      for(var j=0; j<pa.length; j++) {
        var kv = pa[j].split("=");
        p[kv[0]] = kv[1];
      }
      return p;
    }
  }
  return {};
}

GAReviews.windowSize = function(){
  var w = 0;
  if(!window.innerWidth){
    if(!(document.documentElement.clientWidth == 0)){
      w = document.documentElement.clientWidth;
    } else{
      w = document.body.clientWidth;
    }
  } else {
    w = window.innerWidth;
  }
  return w;
};

try{
    if ( typeof jQuery === 'undefined' || (jQuery.fn.jquery.split(".")[0] < 2 && jQuery.fn.jquery.split(".")[1] < 7)) {
        var doNoConflict = true;
        if (typeof jQuery === 'undefined') {doNoConflict = false;}
        GAReviews.loadScript('//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js', function(){
            if (doNoConflict) {
                jQuery17 = jQuery.noConflict(true);
            } else {
                jQuery17 = jQuery;
            }
            GAReviews.init(jQuery17);
        });
    } else {
        GAReviews.init(jQuery);
    }
}catch (e){ console.log('Menu app exception: ' + e)}
