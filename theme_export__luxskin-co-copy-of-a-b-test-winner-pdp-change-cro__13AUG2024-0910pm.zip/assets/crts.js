
function cartqtyupdate(){
jQuery.getJSON('/cart',function(e){
$('.cart-link__bubble,.cartnumber').attr('class','cartnumber')
setTimeout(function(){
$('.cartnumber').text(e.item_count)
},100)
})                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
}
setTimeout(function(){
  cartqtyupdate()
  },100)
setTimeout(function(){

$('[value="Add to cart"],.btn--add-to-cart,.mu_sticky_descktop_atc').on('click',function(){
setTimeout(function(){
cartqtyupdate()
},100)
})
},200)

var cartdrawerr=false;
var _intv = setInterval(function(){
if($('#monster-cart-wrapper').hasClass('mu_openned') && cartdrawerr==false){
cartdrawerr=true;    
}
else if(!$('#monster-cart-wrapper').hasClass('mu_openned') && cartdrawerr==true){
cartdrawerr=false;
cartqtyupdate()
}
},100)