var __isp_options = {
    isp_add_to_cart_callback:function(product_id , form_id ) {

        $jquery_isp("svg.icon.icon-cart").after('<div id="CartCount" class="site-header__cart-count"><span>' +
                ' </span> <span class="icon__fallback-text medium-up--hide">item</span></div>');

        try { document.body.style.cursor = 'initial'; } catch (e) {}
        var cart_selector = ispGetCartSelector();
        try {
            var cart_location_top = (cart_selector) ? cart_selector.offset().top + 10 : 10;
            var cart_location_left = (cart_selector) ? cart_selector.offset().left + 10 : $jquery_isp(window).width() / 2;
        } catch (e) {
            var cart_location_top = 10;
            var cart_location_left= $jquery_isp(window).width() - 10;
        }
        var product_img = $jquery_isp('.isp_grid_product[product_id="' + product_id + '"] img.isp_product_image');
        var z_index = '100';
        // else {
        //     var product_img = $jquery_isp('#isp_product_quick_view_model .isp_quick_view_content_left img');
        //     var z_index = '2147483647';
        // }
        if (product_img) {
            var clone_img = product_img.clone()
                .offset({
                    top: product_img.offset().top + product_img.height(),
                    left: product_img.offset().left
                })
                .css({
                    'opacity': '0.5',
                    'position': 'absolute',
                    'height': '150px',
                    'width': '150px',
                    'z-index': z_index
                })
                .appendTo($jquery_isp('body'))
                .animate({
                    'top': cart_location_top,
                    'left': cart_location_left,
                    'width': 75,
                    'height': 75
                }, 750);

            clone_img.animate({
                'width': 0,
                'height': 0
            }, function () {
                $jquery_isp(this).detach()
            });
        }
        try {  ShopifyAPI.getCart(); } catch (e) {};
        try {
            $jquery_isp.ajax({
                type           : 'POST',
                url            : '/cart.js',
                dataType       : 'json',
                cache          : false
            })
                .done(function(data) {
                    var __platform_cartID = $jquery_isp.cookie('cart');
                    if (__platform_cartID != null && __platform_cartID != '') {
                        $jquery_isp.cookie('__isp_cart_last_known', __platform_cartID, { expires: 365, path: '/' });
                        try { localStorage.setItem('__isp_cart', __platform_cartID); }
                        catch (e) {}
                    }
                    $jquery_isp('#CartCount, span.cart span.count, span.cart-item-count-wrap').html(data.item_count);
                })
                .fail(function(jqXHR, textStatus) {
                });
        } catch (e) {}
    }

};
