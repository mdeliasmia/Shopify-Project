$(document).ready(function(){
  if($('.TablePress').length > 0 ){
    $('<a href="#TablePress_anchor">Click to go to specifications</a>').insertAfter('body.template-product .product-form');
    setTimeout(function(){
    var rcount = parseInt($('.rio-strong.RatingStatistics__number').text());
      if(rcount > 0){
         $('#ReviewsWidget').show();
      }else{
        $('#ReviewsWidget').hide();
      }
      $('.TablePress').attr('id','TablePress_anchor');
    },1500);	
  }
  

  // remove after shipping rate a/b test
  // part 1
  var intervalFunction = function()
  {


    jQuery('.salesbox-content').each(function(){

      if(jQuery(this).text().indexOf('Free shipping') >= 0){
        jQuery(this).parent().remove();

        clearInterval(refreshIntervalId);
      }

    });




  };
  var refreshIntervalId = null;
  refreshIntervalId = setInterval(intervalFunction, 250);

  $("#isp_left_container_facets .isp_search_res_facets_container .isp_facet_value a").attr("rel","nofollow");
  
});

