let selectedColor = $('variant-radios input:checked').attr('value');
$('.thumbnail-list.slider--tablet-up .thumbnail-list__item.slider__slide:not(.slider__slide[thumbnail-color='+selectedColor+'])').css('display','none');

    $('.product:not(.product--columns) .product__media-list .product__media-item').removeClass('is-active');
$('.product--thumbnail_slider .product__media-item[variant-color="' + selectedColor + '"]:first').addClass('is-active');
$(document).ready(function(){
$('media-gallery[aria-label="Gallery Viewer"]').css('opacity',1);
});