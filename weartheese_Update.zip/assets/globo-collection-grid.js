document.addEventListener("DOMContentLoaded", function () {
  function waitForElement(selector, trigger, delayInterval, delayTimeout) {
    var interval = setInterval(function () {
      if (
        document &&
        document.querySelector(selector) &&
        document.querySelectorAll(selector).length > 0
      ) {
        clearInterval(interval);
        trigger();
      }
    }, delayInterval);
    setTimeout(function () {
      clearInterval(interval);
    }, delayTimeout);
  }

  function init() {
    titleDisplay();
  }

  function titleDisplay() {
    var product_container = document.querySelector("#gf-products");
    var product_titles = document.querySelectorAll(
      "#gf-products .collection__grid-product-title p"
    );
    localStorage.setItem("check_name", product_titles[0].textContent.trim());
    var is_matched = false;
    product_titles.forEach((product_title, index) => {
      var current_title = product_title.textContent.trim();
      var storage_title = localStorage.getItem("check_name");
      if (current_title === storage_title) {
        if (is_matched === false) {
          is_matched = true;
        } else {
          product_title.parentNode.classList.add("hide-title");
        }
      } else {
        if (is_matched === true) {
          localStorage.setItem("check_name", product_title.textContent.trim());
        } else {
          product_title.parentNode.classList.add("hide-title");
        }
      }
    });
  }

  setInterval(() => {
    waitForElement("#gf-products modal-opener", init, 50, 10000);
  }, 500);
});
