document.addEventListener("DOMContentLoaded", function () {
  var modals = document.querySelectorAll('.quick-add-modal__content-info');
  setInterval(() => {
    if (window.innerWidth < 750) {
      modals.forEach((modal) => {
        var variant_selector = modal.querySelector('.product__info-wrapper variant-radios');
        var atc_button = modal.querySelector('.product__info-wrapper product-form');
        if(variant_selector && atc_button) {
          modal.querySelector('.product--thumbnail_slider').after(variant_selector);
          variant_selector.after(atc_button);
        }
      });
    }
  }, 500);
});