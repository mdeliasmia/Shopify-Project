document.addEventListener("DOMContentLoaded", function () {
  setTimeout(() => {
    setInterval(() => {
      document.querySelectorAll('.wearetheese-featured-collections swiper-container').forEach((container) => {
        if (container.shadowRoot) {
          var pagination = container.shadowRoot.querySelector('.swiper-pagination');
          pagination.style.position = "relative";
          pagination.style.top = "5px";
        }
      });
    }, 500);
  }, 1000);
});