document.addEventListener("DOMContentLoaded", function () {
  setInterval(() => {
    var get_active_slider = document.querySelector(".product__media-item.is-active");
    var get_thumbnail = document.querySelector("product-media-slider-component");
    if (get_thumbnail) {
      get_thumbnail.style.height = get_active_slider.offsetHeight + "px";
    }
  }, 100);
});
