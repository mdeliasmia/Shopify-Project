document.addEventListener("DOMContentLoaded", function () {
  var getSizeButtons = document.querySelectorAll('.product-form__input.size input[data-value="Size"]');

  getSizeButtons.forEach((sizeButton) => {
    sizeButton.addEventListener("click", () => {
      var cart = document.querySelector('cart-drawer');
      var variantContainer = sizeButton.parentNode.parentNode;
      var productId = variantContainer.getAttribute("data-pr-id");
      var selectedColor = variantContainer.querySelector('input[name="Color-'+productId+'"]:checked');
      var selectedSize = document.querySelector('input[name="Size-'+productId+'"]:checked');
      if (selectedColor) {
        var variantId = variantContainer.querySelector('.variant-options-list [data-variant-title="'+ selectedColor.value + ' / ' + selectedSize.value + '"]').getAttribute("data-pr-variant");

        var productForm = variantContainer.querySelector('.product-form-section form');

        productForm.querySelector('input[name="id"]').value = variantId;

        const formData = new FormData(productForm);

        var result = addToCart(productId, variantId);

        if (result) {
          result.then((response) => {
            localStorage.setItem('executeAfterReload', 'true');
            location.reload();
            console.log(cart);
          }).catch((err) => {
            console.error(err);
          })
        }
      }
      else {
        document.querySelector('.message-container').innerHTML = "Please Select Color First!";
      }
    });
  });

  async function addToCart(productId, variantId, qty = 1) {
    var params = new URLSearchParams({ product_id: productId, id: variantId, quantity: qty }).toString();
    try {
      var response = await fetch("/cart/add.js", {
        method: "post",
        body: params,
        headers: { "content-type": "application/x-www-form-urlencoded; charset=UTF-8" },
      });

      if (response.ok) {
        return await response.json();
      } else {
        throw new Error("Failed to add to cart");
      }
    } catch (e) {
      console.error(e);
    }
  }

  function handleClick(event) {
    var target = event.target;

    if (target.matches('.product-form__input.size legend') || target.closest('.product-form__input.size legend')) {
      var expandButton = target.closest('.product-form__input.size legend');
      expandButton.parentNode.classList.toggle("active");
    }
  }

  document.body.addEventListener('click', handleClick);

  window.onload = function () {
  // Check if the flag is set in local storage
  var executeAfterReload = localStorage.getItem('executeAfterReload');
  
  if (executeAfterReload === 'true') {
    // Code to be executed after the page has fully loaded (after the reload)
    document.querySelector('body').classList.add('overflow-hidden');
    var cart = document.querySelector('cart-drawer');
    cart.classList.add('active');
    
    // Reset the flag in local storage
    localStorage.removeItem('executeAfterReload');
  }
};
});
